"""
AKUMA WEB SCANNER - Simple Backend for Testing
Simplified FastAPI backend for initial testing
By AKUMA & Феня - The Cyber Gods 🔥💀
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
import uvicorn
import datetime
import uuid
import asyncio

# Create FastAPI app
app = FastAPI(
    title="AKUMA Web Scanner - Test API",
    description="🔥 Legendary Cyberpunk Vulnerability Scanner (Test Mode) 🔥",
    version="3.0-test"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-memory storage for testing
scans_db = {}

# Pydantic models
class ScanRequest(BaseModel):
    name: str
    targets: List[str]
    scan_type: Optional[str] = "full"

class ScanResponse(BaseModel):
    id: str
    name: str
    targets: List[str]
    status: str
    created_at: str
    progress: int = 0

@app.get("/")
async def root():
    return {
        "message": "🔥 AKUMA Web Scanner v3.0 - Test API 🔥",
        "status": "running",
        "version": "3.0-test"
    }

@app.get("/api/health")
async def health_check():
    return {
        "status": "healthy",
        "version": "3.0-test",
        "message": "🚀 AKUMA Scanner is ready for action!"
    }

@app.get("/api/test")
async def test_endpoint():
    return {
        "message": "🎯 Test endpoint working!",
        "scanner": "AKUMA TURBO v3.0",
        "mode": "testing"
    }

@app.get("/api/scans")
async def get_scans():
    """Get all scans"""
    return list(scans_db.values())

@app.post("/api/scans")
async def create_scan(scan_request: ScanRequest):
    """Create new scan"""
    scan_id = str(uuid.uuid4())[:8]
    
    new_scan = {
        "id": scan_id,
        "name": scan_request.name,
        "targets": scan_request.targets,
        "status": "pending",
        "created_at": datetime.datetime.now().isoformat(),
        "progress": 0,
        "vulnerabilities": [],
        "scan_type": scan_request.scan_type
    }
    
    scans_db[scan_id] = new_scan
    
    # Start mock scan in background
    asyncio.create_task(run_mock_scan(scan_id))
    
    return new_scan

@app.get("/api/scans/{scan_id}")
async def get_scan(scan_id: str):
    """Get specific scan"""
    if scan_id not in scans_db:
        raise HTTPException(status_code=404, detail="Scan not found")
    
    return scans_db[scan_id]

@app.delete("/api/scans/{scan_id}")
async def delete_scan(scan_id: str):
    """Delete scan"""
    if scan_id not in scans_db:
        raise HTTPException(status_code=404, detail="Scan not found")
    
    del scans_db[scan_id]
    return {"message": f"Scan {scan_id} deleted"}

async def run_mock_scan(scan_id: str):
    """Mock scan execution for testing"""
    if scan_id not in scans_db:
        return
    
    scan = scans_db[scan_id]
    
    # Update status to running
    scan["status"] = "running"
    scan["progress"] = 10
    
    await asyncio.sleep(2)
    scan["progress"] = 30
    
    await asyncio.sleep(2)
    scan["progress"] = 60
    
    # Add some mock vulnerabilities
    scan["vulnerabilities"] = [
        {
            "id": "vuln_1",
            "type": "Missing Security Headers",
            "severity": "Medium",
            "target": scan["targets"][0] if scan["targets"] else "unknown",
            "description": "Missing X-Frame-Options header"
        },
        {
            "id": "vuln_2", 
            "type": "Directory Listing",
            "severity": "Low",
            "target": scan["targets"][0] if scan["targets"] else "unknown",
            "description": "Directory listing enabled at /admin/"
        }
    ]
    
    await asyncio.sleep(3)
    scan["progress"] = 100
    scan["status"] = "completed"
    scan["completed_at"] = datetime.datetime.now().isoformat()

@app.get("/api/dashboard/stats")
async def get_dashboard_stats():
    """Get dashboard statistics"""
    total_scans = len(scans_db)
    running_scans = len([s for s in scans_db.values() if s["status"] == "running"])
    completed_scans = len([s for s in scans_db.values() if s["status"] == "completed"])
    
    total_vulns = 0
    critical_vulns = 0
    high_vulns = 0
    
    for scan in scans_db.values():
        vulns = scan.get("vulnerabilities", [])
        total_vulns += len(vulns)
        critical_vulns += len([v for v in vulns if v.get("severity") == "Critical"])
        high_vulns += len([v for v in vulns if v.get("severity") == "High"])
    
    return {
        "total_scans": total_scans,
        "running_scans": running_scans,
        "completed_scans": completed_scans,
        "total_vulnerabilities": total_vulns,
        "critical_vulnerabilities": critical_vulns,
        "high_vulnerabilities": high_vulns
    }

if __name__ == "__main__":
    uvicorn.run(
        "simple_main:app",
        host="0.0.0.0",
        port=8000,
        reload=True
    )
