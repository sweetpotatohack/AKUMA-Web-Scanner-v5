# AKUMA WEB SCANNER - Backend App Module
# By AKUMA & Феня - The Cyber Gods 🔥💀
